import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.util.ArrayList;

import javax.swing.JPanel;


public class Gra extends JPanel
{
	protected ArrayList<Gracz> gracze;
	protected String mapa;
	protected TypGry typ_gry;
	protected String mapa_src = "";
	protected static int WIDTH,HEIGHT;
	
	public Gra(int width, int height)
	{
		this.HEIGHT = height;
		this.WIDTH = width;
		this.setLayout(null);
		this.setPreferredSize(new Dimension(this.WIDTH, this.HEIGHT));
	}
	
	
	 @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        g2d.setColor(Color.RED);
        g2d.fillRect(0, 0, WIDTH, HEIGHT);
        
    }
}
