import java.util.ArrayList;


public abstract class Druzynowa extends TypGry 
{
	protected Druzyna druzyna_a;
	protected Druzyna druzyna_b;
}
