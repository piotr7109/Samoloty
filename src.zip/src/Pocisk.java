
public class Pocisk 
{
	private String typ;
	private int x,y;
	
}
