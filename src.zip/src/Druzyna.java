import java.util.ArrayList;


public class Druzyna 
{
	private String nazwa;
	private ArrayList<Gracz> gracze;
	private int punkty;
}
