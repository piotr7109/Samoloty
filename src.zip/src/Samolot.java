import java.util.ArrayList;


public class Samolot 
{
	private int x, y;
	private int punkty_zycia;
	private ArrayList<Pocisk> pociski;
	private int ilosc_bomb;
	
}
