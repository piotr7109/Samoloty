
public abstract class TypGry 
{

}
