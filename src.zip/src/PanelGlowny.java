import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.GridLayout;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;



public class PanelGlowny extends JPanel {

	public PanelGlowny()
	{
		super(new GridLayout(1, 1));
		
		JTabbedPane panel = new JTabbedPane();
		panel.addTab("Samoloty", new Gra(600,600));
		
		
		
		this.add(panel);
		
		panel.setTabLayoutPolicy(JTabbedPane.SCROLL_TAB_LAYOUT);
	}
	private static void createAndShowGUI() 
	{
        //Create and set up the window.
        JFrame frame = new JFrame("Samoloty");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        //Add content to the window.
        frame.add(new PanelGlowny(), BorderLayout.CENTER);
        
        //Display the window.
        frame.pack();
        frame.setVisible(true);
    }
	public static void main(String[] args) 
	{
        
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                //Turn off metal's use of bold fonts
				UIManager.put("swing.boldMetal", Boolean.FALSE);
				createAndShowGUI();
            }
        });
    }
}
