
public class Gracz
{
	private int id;
	private int login;
	private int ip;
	private Samolot samolot;
	private int punkty;
	private int fragi;

}
